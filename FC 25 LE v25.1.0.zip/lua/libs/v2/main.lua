local LIVE_EDITOR = require 'imports/core/live_editor'

LE = LIVE_EDITOR:new()
LE:Load()
